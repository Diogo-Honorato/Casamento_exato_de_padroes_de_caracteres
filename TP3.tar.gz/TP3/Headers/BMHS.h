#ifndef _BHMS_H_
#define _BHMS_H_

int BMHS(char *texto, char *padrao, int inicio, int fim);



#endif