#ifndef _SHIFTAND_H_
#define _SHIFTAND_H_

int shiftAnd(char *texto, char *padrao, int inicio, int fim);



#endif